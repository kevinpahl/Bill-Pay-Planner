# Bill Pay Planner (Streamlit)

Shows which paycheck pays which bill, what's left over from each check, and a running total, projected forward from your Finances.xlsx.

## Run it

1. Install Python 3.10 or newer.
2. In this folder, install the packages:

       pip install -r requirements.txt

3. Start the app:

       streamlit run app.py

   It opens in your browser at http://localhost:8501.

## Files

- `app.py`: the Streamlit app (pages, tables, chart).
- `engine.py`: the rules that pick a paycheck for each bill. No Streamlit code, so it's easy to change.
- `data.py`: starting data from your spreadsheet, saving, and importing an updated Finances.xlsx.
- `planner_data.json`: created the first time you change something. It holds your bills, paychecks, paid ticks and moves. Delete it to start over from the spreadsheet values.

## Updating from Excel

Use **Update from Excel** in the sidebar. It expects the same layout as Finances.xlsx: due day in column A, bill name in B, amount in C (starting row 2), first payday in E8, and the two paychecks in F11/G11 and F12/G12 (gross/personal).
